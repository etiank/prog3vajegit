package org.Vaje9;

public enum MessageType {
    CHAT,
    PEER_DISCOVERY_REQUEST,
    PEER_DISCOVERY_RESPONSE,
}
