package org.Vaje9;

public class Constants {
    public static final int PORT = 7777;
    public static final String MY_IP = "172.16.153.31";//moj IP
    public static final String BOOTSTRAP_IP = "172.16.153.10";//profesorjev IP
    public static final String USERNAME = "tj_kreem";
    

}
