package org.Vaje2;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter {
    public int count=0;
}
