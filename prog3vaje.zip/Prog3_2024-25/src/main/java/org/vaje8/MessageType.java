package org.vaje8;

public enum MessageType {
    CHAT,
    PEER_DISCOVERY_REQUEST,
    PEER_DISCOVERY_RESPONSE,
}
