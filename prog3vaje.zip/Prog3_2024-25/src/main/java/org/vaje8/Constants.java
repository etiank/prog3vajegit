package org.vaje8;

public class Constants {
    public static final int PORT = 7777;
    public static final String MY_IP = "172.16.153.30";//moj IP
    public static final String BOOTSTRAP_IP = "172.16.153.10";//profesorjev IP
    

}
