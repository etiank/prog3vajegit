package org.Vaje5_producerConsumer;

public enum EventType {
    CreateTicket,
    ValidateTicket,
    UseTicket,
}
