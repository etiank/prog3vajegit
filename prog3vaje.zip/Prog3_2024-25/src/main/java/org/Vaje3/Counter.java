package org.Vaje3;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter {
    public AtomicInteger count=new AtomicInteger(0);
}
