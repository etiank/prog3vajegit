package org.Vaje3;

public enum CounterSelector {
    First,
    Second,
}
