package util;

public enum LogLevel {
    Info,
    Debug,
    Warn,
    Error,
    Success,
    Status
}
